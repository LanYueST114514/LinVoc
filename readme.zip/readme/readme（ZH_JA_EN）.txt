中文

关于本项目

本网页程序由人工智能生成辅助完成。作者在提示词设计、需求构思、功能调试、格式规范、整合排版与整体项目管理上投入了时间与精力，对最终成品享有完整著作权。

版权声明 & 开源协议（MIT）

版权所有 (c) 2026 LanYueST

现授予任何获得本软件及相关文档文件（下称“本软件”）的人士免费许可，允许不受限制地使用、复制、修改、合并、发布、分发、再许可和/或销售本软件的副本，但需遵守以下条件：

上述版权声明及本许可声明须包含在本软件的所有副本或主要内容中。

本软件按“原样”提供，不附带任何明示或暗示的保证，包括但不限于对适销性、特定用途适用性和非侵权性的保证。在任何情况下，作者或版权持有人均不对因使用本软件而产生的任何索赔、损害或其他责任承担责任。

日本語

このプロジェクトについて

本ウェブページはAIによる支援を受けて作成されました。作者はプロンプト作成、構想設計、機能調整、フォーマット調整、統合・レイアウトおよびプロジェクト全体の管理に時間と労力を費やし、完成品に対して完全な著作権を有します。

著作権表示＆オープンソースライセンス（MIT）

Copyright (c) 2026 LanYueST

本ソフトウェアおよび関連ドキュメントファイル（以下「本ソフトウェア」）を入手したすべての方に、無償で以下の権利が許諾されます。本ソフトウェアを無制限に使用、複製、改変、統合、公開、頒布、サブライセンス、販売することができます。ただし、以下の条件を遵守してください。

上記の著作権表示および本許諾表示は、本ソフトウェアのすべての複製物または主要部分に記載されるものとします。

本ソフトウェアは「現状のまま」提供され、商品性、特定目的への適合性、非侵害性を含む明示または黙示の保証は一切ありません。いかなる場合においても、作者または著作権者は、本ソフトウェアの使用に関連して生じた請求、損害またはその他の責任について、一切の責任を負いません。

English

About this project

This webpage was created with the assistance of artificial intelligence. The author has invested time and effort in prompt design, concept development, function debugging, formatting, integration, layout, and overall project management, and retains full copyright of the final product.

Copyright & Open Source License (MIT)

Copyright (c) 2026 LanYueST

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.